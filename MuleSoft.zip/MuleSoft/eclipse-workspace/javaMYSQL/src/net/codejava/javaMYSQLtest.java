package net.codejava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class javaMYSQLtest {
			public static void main(String[] args)
			{
			String url = "jdbc:mysql://localhost:3306/j";
			String username = "root";
			String password = "john1998#tag";
		
		try {
		Connection con = DriverManager.getConnection(url, username, password);
		String sql = "select * from movies";
		Statement st = con.createStatement();
		ResultSet re = st.executeQuery(sql);
		int count = 0;
		while (re.next()) {
			String movie = re.getString("Movie_Name");
			String actor = re.getString("Actor_Name");
			String actress = re.getString("Actress_Name");
			String director = re.getString("Director");
			String year = re.getString("Year_of_release");
			count++;
			System.out.println(movie);
			System.out.println(actor);
			System.out.println(actress);
			System.out.println(director);
			System.out.println(year);
			System.out.println("--------------------------------------------------");
		}
		con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	 }
}

