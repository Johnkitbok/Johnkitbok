import java.sql.*;

public class moviesMYSQL {
	public static void main(String args[])throws Exception {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc.mysql://localhost:3306/j","root","john1998##tag");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from movies");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(3));
				con.close();
			}
		}
		catch(Exception e)
		{
			System.out.println(e); 
		}
	}
}
